import express from "express";
import cors from "cors";
import router from "../routes/router.js";   // Rutas principales
import authRoutes from "../routes/authroutes.js"; // 🔹 Rutas de autenticación
import dotenv from "dotenv";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

// 🔹 Rutas principales del proyecto
app.use("/api", router);

// 🔹 Rutas de autenticación (recuperar contraseña)
app.use("/api/auth", authRoutes);

// 🔹 Puerto 4000 (por defecto)
const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
