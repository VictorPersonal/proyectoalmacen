import React from "react";
import FavoritoProducto from "../components/FavoritoProducto";

const Favoritos = () => {
  return (
    <div style={{ padding: "20px" }}>
      <FavoritoProducto />
    </div>
  );
};
//hola
export default Favoritos;
